docker compose up --build
