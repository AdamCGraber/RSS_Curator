docker compose exec worker python worker.py ingest
